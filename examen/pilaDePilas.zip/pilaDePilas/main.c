#include "pilaDePilas.h"

int main()
{
    tPilaE p;

    crearPilaE(&p);

    crearLote(&p);
    vaciarYmostrarPPE(&p);

    return 0;
}
