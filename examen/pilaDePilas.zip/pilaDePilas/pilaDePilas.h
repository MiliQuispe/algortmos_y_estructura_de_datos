#ifndef PILADEPILAS_H_INCLUDED
#define PILADEPILAS_H_INCLUDED


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pilaD.h"
#include "pilaE.h"

void  crearLote(tPilaE* p);

void vaciarYmostrarPPE(tPilaE* p);


#endif // PILADEPILAS_H_INCLUDED
